<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6f2e9686             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
