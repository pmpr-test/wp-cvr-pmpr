<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dda1bd9fd51             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
