<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d369e9de             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
