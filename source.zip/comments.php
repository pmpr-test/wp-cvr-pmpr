<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e580bc35e5e             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
