<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e598d5d43bf             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
