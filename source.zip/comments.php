<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc702e857da             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
