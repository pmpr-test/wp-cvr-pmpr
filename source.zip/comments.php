<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e59e5a7675d             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
