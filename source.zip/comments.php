<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71cf21480             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
