<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520e51b858             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component; use Pmpr\Cover\Pmpr\Component\Module\Contact; use Pmpr\Cover\Pmpr\Container; class Component extends Container { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
