<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c424d8d838             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component; use Pmpr\Cover\Pmpr\Component\Module\Contact; use Pmpr\Cover\Pmpr\Container; class Component extends Container { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
