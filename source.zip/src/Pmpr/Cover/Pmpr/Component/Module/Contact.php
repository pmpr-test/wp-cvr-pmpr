<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e16e2f881             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\x74\137\143\157\156\164\x61\x63\x74\137\146\157\x72\155\137\146\x69\145\154\x64\x73", [$this, "\x67\x69\x6f\155\x67\x61\x79\151\x71\x65\143\143\147\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\156\55\x70\x72\151\155\x61\x72\171\40\x68\157\166\x65\x72\55\x6f\165\164\154\x69\156\x65\x20\144\55\x66\154\145\x78"); } } return $ikgwqyuyckaewsow; } }
