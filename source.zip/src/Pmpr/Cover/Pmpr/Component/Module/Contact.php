<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77b8552a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\137\143\x6f\x6e\x74\x61\x63\x74\137\146\157\x72\155\x5f\x66\151\x65\154\x64\163", [$this, "\147\151\157\x6d\x67\141\x79\151\x71\145\x63\143\147\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto quyogmwugsyoaaiu; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\x2d\160\x72\151\155\141\x72\171\x20\150\157\x76\x65\162\55\157\165\x74\x6c\151\156\x65\40\x64\x2d\x66\x6c\145\170"); quyogmwugsyoaaiu: skuqigsokaguscas: } sgiwoiscywusgmmm: return $ikgwqyuyckaewsow; } }
