<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b5df5a2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\137\143\157\156\164\x61\143\x74\137\146\x6f\x72\x6d\137\146\151\x65\154\144\x73", [$this, "\147\x69\157\155\147\141\x79\151\x71\145\143\x63\147\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\x2d\160\162\x69\x6d\141\162\171\40\150\157\x76\x65\x72\x2d\x6f\165\x74\x6c\x69\156\145\x20\x64\x2d\146\154\x65\x78"); } } return $ikgwqyuyckaewsow; } }
