<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675815f2d6947             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\x5f\x63\x6f\x6e\164\x61\143\164\137\x66\x6f\x72\155\137\146\151\145\154\144\163", [$this, "\147\x69\157\x6d\x67\141\171\151\161\x65\x63\x63\x67\141\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\x2d\160\162\x69\155\141\162\171\40\x68\157\166\145\x72\55\157\x75\x74\x6c\x69\156\x65\x20\x64\55\146\x6c\x65\x78"); } } return $ikgwqyuyckaewsow; } }
