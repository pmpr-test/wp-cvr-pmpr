<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705174dabba2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\164\x5f\x63\157\156\164\x61\x63\x74\x5f\146\x6f\162\x6d\x5f\146\x69\x65\154\144\x73", [$this, "\x67\151\x6f\x6d\147\141\x79\x69\x71\x65\x63\143\147\x61\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto omqiayeucoioqoao; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\156\55\160\162\151\155\141\x72\171\x20\150\157\x76\145\x72\55\x6f\x75\x74\x6c\x69\x6e\x65\40\x64\55\x66\154\145\170"); omqiayeucoioqoao: igooksugieceoege: } cewmoqyysgsmuiya: return $ikgwqyuyckaewsow; } }
