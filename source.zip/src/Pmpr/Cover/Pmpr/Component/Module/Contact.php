<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0002d08db             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\137\143\157\x6e\x74\x61\x63\x74\137\146\157\162\155\137\146\151\x65\x6c\x64\x73", [$this, "\x67\x69\x6f\x6d\147\x61\171\x69\161\x65\x63\143\x67\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\x6e\55\160\x72\x69\x6d\x61\162\171\x20\x68\x6f\x76\145\x72\55\x6f\165\164\x6c\151\x6e\x65\x20\x64\x2d\x66\x6c\x65\x78"); } } return $ikgwqyuyckaewsow; } }
