<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebec7b4f6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\137\x63\157\156\x74\141\143\164\x5f\146\x6f\x72\x6d\x5f\146\151\x65\x6c\x64\x73", [$this, "\147\151\157\x6d\147\141\171\151\x71\145\x63\143\147\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto quyogmwugsyoaaiu; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\x6e\x2d\x70\x72\151\x6d\x61\x72\x79\40\150\x6f\x76\145\162\55\x6f\x75\164\x6c\x69\156\145\x20\x64\x2d\146\154\145\x78"); quyogmwugsyoaaiu: skuqigsokaguscas: } sgiwoiscywusgmmm: return $ikgwqyuyckaewsow; } }
