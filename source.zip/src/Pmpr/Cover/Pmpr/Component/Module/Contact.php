<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c6f94e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\137\x63\157\156\x74\x61\x63\164\x5f\146\x6f\x72\x6d\x5f\146\151\x65\154\x64\x73", [$this, "\x67\x69\x6f\x6d\x67\141\171\151\161\145\143\x63\x67\141\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\55\160\162\x69\155\141\162\x79\x20\x68\x6f\x76\x65\x72\55\x6f\165\x74\154\151\x6e\145\40\144\x2d\x66\154\x65\x78"); } } return $ikgwqyuyckaewsow; } }
