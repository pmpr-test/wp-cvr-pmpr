<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0678d0ad             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\137\143\157\x6e\164\141\143\164\137\146\157\x72\155\x5f\x66\x69\145\x6c\144\x73", [$this, "\147\x69\x6f\x6d\147\141\171\x69\x71\145\143\x63\147\141\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\156\x2d\160\162\151\155\141\162\171\40\x68\x6f\x76\x65\x72\55\x6f\x75\164\154\151\x6e\145\x20\x64\x2d\x66\154\145\170"); } } return $ikgwqyuyckaewsow; } }
