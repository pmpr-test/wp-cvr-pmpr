<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae197df2dd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\164\x5f\x63\157\x6e\x74\141\143\x74\137\x66\157\162\x6d\137\x66\x69\145\x6c\144\x73", [$this, "\147\x69\157\155\x67\141\x79\151\161\145\143\143\147\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto igooksugieceoege; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\x2d\x70\162\151\x6d\141\162\x79\x20\x68\157\x76\x65\x72\x2d\157\x75\x74\154\151\x6e\145\40\144\55\146\x6c\x65\170"); igooksugieceoege: cewmoqyysgsmuiya: } scisgsyemmsekgos: return $ikgwqyuyckaewsow; } }
