<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c037a3c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\x74\x5f\143\x6f\156\x74\141\143\164\137\146\x6f\162\155\x5f\x66\x69\145\154\x64\x73", [$this, "\x67\151\x6f\155\x67\x61\171\x69\161\145\x63\143\x67\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\55\160\x72\x69\155\x61\x72\x79\40\150\157\166\x65\x72\x2d\x6f\165\x74\154\x69\x6e\x65\40\x64\55\146\x6c\145\170"); } } return $ikgwqyuyckaewsow; } }
