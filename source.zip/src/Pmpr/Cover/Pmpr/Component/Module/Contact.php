<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fd752f11             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\137\x63\157\x6e\x74\x61\x63\164\137\146\157\162\155\137\x66\x69\x65\154\x64\163", [$this, "\x67\151\157\x6d\x67\141\171\151\x71\x65\143\143\x67\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\55\160\162\x69\x6d\141\x72\x79\40\x68\157\x76\x65\x72\55\157\x75\x74\154\x69\156\x65\x20\144\x2d\146\154\x65\x78"); } } return $ikgwqyuyckaewsow; } }
