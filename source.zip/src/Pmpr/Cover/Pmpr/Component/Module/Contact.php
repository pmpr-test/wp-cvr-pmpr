<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758160b4bf7f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\137\143\x6f\156\164\141\x63\164\x5f\146\x6f\x72\155\137\x66\151\x65\154\144\163", [$this, "\x67\x69\157\155\x67\x61\171\x69\x71\x65\143\x63\147\x61\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\156\x2d\160\x72\151\x6d\141\x72\x79\x20\150\157\166\145\x72\x2d\x6f\x75\x74\154\x69\x6e\x65\x20\144\x2d\x66\154\x65\x78"); } } return $ikgwqyuyckaewsow; } }
