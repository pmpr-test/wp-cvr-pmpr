<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520e51b858             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\x5f\x63\157\x6e\x74\x61\143\x74\x5f\x66\157\162\x6d\137\146\x69\145\154\x64\163", [$this, "\x67\151\157\x6d\147\141\171\151\161\x65\143\143\x67\141\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto omqiayeucoioqoao; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\156\55\x70\x72\151\x6d\141\x72\x79\x20\x68\157\166\x65\162\x2d\x6f\165\164\154\x69\156\145\x20\x64\55\146\x6c\145\170"); omqiayeucoioqoao: igooksugieceoege: } cewmoqyysgsmuiya: return $ikgwqyuyckaewsow; } }
