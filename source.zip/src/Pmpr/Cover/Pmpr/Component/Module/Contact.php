<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46a91a961             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\x5f\143\157\x6e\164\141\143\164\137\146\157\162\155\137\x66\151\145\x6c\144\x73", [$this, "\147\151\x6f\155\x67\x61\x79\x69\x71\145\143\x63\147\x61\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\55\x70\162\x69\155\141\162\171\x20\150\157\x76\145\162\x2d\157\165\x74\154\151\x6e\x65\40\x64\55\146\x6c\145\170"); } } return $ikgwqyuyckaewsow; } }
