<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8614636e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\137\x63\x6f\156\164\141\143\x74\x5f\x66\x6f\x72\155\x5f\146\x69\145\154\x64\x73", [$this, "\147\x69\157\x6d\147\141\x79\x69\161\145\143\143\x67\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto igooksugieceoege; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\x6e\x2d\x70\x72\151\155\x61\162\171\40\x68\157\166\145\x72\55\157\x75\164\154\151\x6e\145\40\x64\x2d\x66\154\145\x78"); igooksugieceoege: cewmoqyysgsmuiya: } scisgsyemmsekgos: return $ikgwqyuyckaewsow; } }
