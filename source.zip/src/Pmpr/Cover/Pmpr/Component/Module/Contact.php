<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e8485ec20             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\137\143\x6f\x6e\x74\141\x63\x74\137\146\157\162\155\137\146\x69\145\154\x64\x73", [$this, "\147\151\157\x6d\x67\141\x79\151\x71\x65\x63\143\147\x61\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\156\55\160\162\x69\155\x61\162\171\x20\x68\x6f\x76\145\x72\x2d\x6f\x75\164\x6c\x69\x6e\145\x20\144\55\x66\x6c\x65\170"); } } return $ikgwqyuyckaewsow; } }
