<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef509c6b563             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\137\x63\157\156\164\x61\x63\164\137\146\157\162\155\x5f\x66\151\145\x6c\144\163", [$this, "\147\151\157\155\147\x61\171\151\x71\x65\143\x63\x67\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto igooksugieceoege; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\x2d\x70\x72\x69\155\x61\x72\x79\40\x68\x6f\x76\x65\x72\55\x6f\165\164\154\x69\156\x65\x20\x64\x2d\146\154\145\x78"); igooksugieceoege: cewmoqyysgsmuiya: } scisgsyemmsekgos: return $ikgwqyuyckaewsow; } }
