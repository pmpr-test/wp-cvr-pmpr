<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46a91a961             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\x5f\156\x61\x76", [$this, "\156\x6b\x79\x63\163\x77\145\x69\141\x67\147\x75\x63\163\165\161"])->waqewsckuayqguos("\x61\155\x70\x5f\x68\145\x61\144\145\x72\137\x65\156\x64", [$this, "\x73\167\x6f\161\x6d\x67\141\163\x79\157\x67\x71\165\157\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\x6e\144\x65\x72\137\x6c\157\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\156\x74\x61\x69\x6e\x65\x72\x5f\143\154\x61\x73\163" => "\x64\x2d\146\154\145\x78\40\152\165\x73\164\151\x66\171\55\x63\157\156\164\145\156\x74\x2d\143\145\x6e\164\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\x64\145\x72\x5f\x65\x6e\144", ["\156\x6f\x6e\x65\x5f\x61\155\160" => __("\116\x6f\x6e\145\40\x41\115\x50\40\126\x65\x72\163\x69\157\x6e", PR__CVR__PMPR)]); } }
