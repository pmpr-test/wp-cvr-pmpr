<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae197df2dd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\x70\x5f\156\141\x76", [$this, "\156\153\x79\x63\x73\167\x65\x69\x61\x67\x67\x75\143\x73\165\161"])->waqewsckuayqguos("\x61\x6d\160\137\150\x65\141\144\x65\162\x5f\145\156\144", [$this, "\x73\167\157\x71\x6d\x67\x61\x73\x79\157\x67\161\x75\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\156\144\145\162\137\x6c\x6f\147\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\156\164\x61\151\156\145\162\x5f\143\x6c\141\x73\x73" => "\144\55\146\x6c\x65\x78\40\152\x75\163\x74\151\x66\x79\x2d\x63\157\156\x74\x65\x6e\x74\x2d\x63\145\x6e\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\141\144\145\162\x5f\145\156\x64", ["\156\x6f\156\145\137\x61\x6d\x70" => __("\x4e\157\x6e\145\x20\101\115\120\x20\126\x65\x72\163\151\157\156", PR__CVR__PMPR)]); } }
