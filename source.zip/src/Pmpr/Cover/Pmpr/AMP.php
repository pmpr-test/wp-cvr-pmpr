<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fd752f11             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\x5f\156\141\166", [$this, "\x6e\x6b\171\143\163\x77\145\x69\x61\147\x67\165\143\x73\165\x71"])->waqewsckuayqguos("\x61\x6d\160\137\150\x65\141\144\x65\x72\137\x65\x6e\144", [$this, "\x73\167\157\161\155\x67\x61\163\x79\157\147\161\x75\157\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\x6e\x64\145\162\137\x6c\x6f\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\x6e\x74\141\x69\156\x65\162\137\x63\x6c\x61\163\163" => "\x64\55\146\x6c\145\170\40\152\x75\163\164\151\x66\x79\55\x63\x6f\156\x74\x65\156\x74\55\x63\x65\156\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\x64\x65\162\137\x65\156\144", ["\156\x6f\x6e\145\x5f\x61\155\160" => __("\116\157\x6e\145\x20\x41\115\x50\40\x56\145\x72\x73\x69\x6f\156", PR__CVR__PMPR)]); } }
