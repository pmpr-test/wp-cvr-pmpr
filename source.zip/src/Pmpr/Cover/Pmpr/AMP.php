<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8614636e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\137\156\x61\166", [$this, "\156\153\x79\143\x73\167\x65\151\x61\x67\147\165\x63\163\x75\x71"])->waqewsckuayqguos("\x61\155\160\x5f\150\145\x61\x64\145\x72\137\x65\x6e\x64", [$this, "\x73\x77\157\x71\x6d\147\141\x73\x79\x6f\147\161\165\157\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\144\x65\162\137\x6c\157\x67\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\x6f\156\x74\x61\151\x6e\145\162\137\x63\x6c\141\x73\x73" => "\x64\x2d\146\154\145\170\x20\152\165\x73\x74\151\146\171\x2d\x63\157\x6e\x74\x65\156\164\55\143\145\156\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\x61\144\145\162\x5f\145\156\144", ["\156\157\156\x65\x5f\x61\155\x70" => __("\116\157\156\145\40\x41\x4d\120\x20\x56\x65\162\163\151\157\x6e", PR__CVR__PMPR)]); } }
