<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758160b4bf7f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\160\x5f\156\141\166", [$this, "\156\x6b\x79\143\x73\167\145\x69\141\147\147\165\143\163\x75\161"])->waqewsckuayqguos("\141\x6d\160\x5f\150\x65\x61\144\145\x72\137\x65\156\x64", [$this, "\163\x77\157\161\x6d\147\141\163\x79\157\x67\161\165\157\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\x64\x65\x72\x5f\154\x6f\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\156\x74\141\x69\156\145\x72\x5f\x63\154\141\x73\163" => "\x64\55\146\154\145\170\x20\152\x75\163\164\x69\146\x79\55\143\x6f\156\x74\x65\156\164\x2d\x63\145\156\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\144\x65\162\137\145\x6e\x64", ["\x6e\157\156\x65\x5f\x61\x6d\160" => __("\x4e\x6f\x6e\x65\40\x41\x4d\x50\40\x56\x65\x72\163\x69\157\x6e", PR__CVR__PMPR)]); } }
