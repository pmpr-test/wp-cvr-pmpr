<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e16e2f881             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\x5f\156\141\x76", [$this, "\x6e\153\171\x63\x73\x77\x65\151\x61\147\x67\165\x63\x73\x75\161"])->waqewsckuayqguos("\141\x6d\160\x5f\x68\145\x61\144\x65\x72\137\145\x6e\144", [$this, "\x73\167\x6f\x71\x6d\147\141\163\171\x6f\147\x71\165\x6f\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\x64\x65\162\x5f\154\157\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\156\x74\x61\x69\156\145\162\137\143\x6c\141\x73\x73" => "\144\55\x66\x6c\x65\x78\x20\152\165\x73\164\x69\146\171\55\143\157\156\x74\x65\156\164\55\143\145\156\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\x64\145\x72\137\x65\x6e\144", ["\x6e\157\x6e\x65\137\x61\x6d\x70" => __("\x4e\x6f\x6e\x65\x20\x41\x4d\x50\40\126\x65\162\x73\151\x6f\x6e", PR__CVR__PMPR)]); } }
