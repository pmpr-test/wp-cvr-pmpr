<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705174dabba2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\x6e\141\x76", [$this, "\x6e\153\171\x63\x73\x77\145\151\x61\x67\x67\x75\143\163\x75\161"])->waqewsckuayqguos("\x61\155\160\x5f\150\x65\x61\x64\x65\x72\x5f\145\156\144", [$this, "\163\167\x6f\x71\x6d\147\x61\163\171\157\x67\x71\165\157\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\156\144\x65\162\137\x6c\157\147\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\x6e\164\141\x69\156\145\162\137\143\154\x61\x73\163" => "\x64\x2d\x66\154\x65\170\x20\152\165\x73\164\x69\x66\x79\x2d\x63\x6f\156\x74\145\x6e\x74\55\x63\x65\156\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\141\x64\145\x72\137\145\x6e\x64", ["\x6e\157\x6e\x65\137\141\155\160" => __("\x4e\x6f\156\145\x20\x41\115\120\x20\126\145\x72\x73\x69\x6f\x6e", PR__CVR__PMPR)]); } }
