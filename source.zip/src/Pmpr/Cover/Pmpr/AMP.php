<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0002d08db             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\160\x5f\x6e\x61\x76", [$this, "\x6e\153\x79\x63\x73\x77\x65\x69\x61\x67\x67\x75\x63\163\x75\161"])->waqewsckuayqguos("\141\x6d\160\x5f\150\x65\x61\x64\x65\x72\x5f\145\x6e\x64", [$this, "\x73\x77\x6f\x71\155\x67\x61\x73\171\157\x67\161\x75\x6f\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\144\x65\162\x5f\x6c\157\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\156\x74\x61\x69\x6e\x65\162\137\x63\154\141\x73\163" => "\x64\x2d\x66\x6c\x65\x78\x20\152\x75\x73\164\151\146\x79\x2d\143\157\x6e\x74\145\156\164\55\143\x65\x6e\x74\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\x64\145\x72\x5f\x65\156\144", ["\x6e\x6f\156\145\x5f\x61\x6d\x70" => __("\116\157\x6e\145\40\101\115\120\40\126\x65\162\163\x69\157\156", PR__CVR__PMPR)]); } }
