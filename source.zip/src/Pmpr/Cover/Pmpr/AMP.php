<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b5df5a2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\x6e\x61\166", [$this, "\x6e\x6b\x79\x63\163\167\145\151\141\x67\x67\165\143\163\x75\x71"])->waqewsckuayqguos("\x61\155\x70\137\150\145\x61\x64\x65\x72\137\x65\x6e\x64", [$this, "\x73\167\x6f\x71\x6d\x67\x61\x73\171\157\x67\161\x75\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\156\x64\x65\162\x5f\154\x6f\x67\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\x6f\x6e\164\x61\x69\x6e\145\162\x5f\x63\154\141\x73\x73" => "\x64\55\x66\154\x65\170\40\152\165\163\164\151\146\171\x2d\x63\x6f\156\x74\x65\x6e\x74\55\143\x65\x6e\x74\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\141\144\145\162\x5f\145\x6e\144", ["\x6e\157\156\x65\137\141\155\x70" => __("\116\x6f\156\145\x20\x41\x4d\x50\40\x56\x65\162\x73\x69\x6f\156", PR__CVR__PMPR)]); } }
