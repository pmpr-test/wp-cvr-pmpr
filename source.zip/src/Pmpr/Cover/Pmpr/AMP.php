<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0678d0ad             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\137\x6e\141\166", [$this, "\156\x6b\171\x63\163\167\145\x69\x61\147\147\165\x63\x73\165\x71"])->waqewsckuayqguos("\141\x6d\160\137\x68\x65\141\144\145\x72\137\x65\x6e\144", [$this, "\163\x77\x6f\x71\155\147\x61\x73\x79\x6f\147\161\165\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\144\x65\162\137\154\157\x67\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\164\141\x69\156\145\x72\137\143\154\x61\163\x73" => "\144\x2d\146\154\x65\x78\x20\152\165\163\164\x69\146\171\x2d\x63\x6f\156\x74\x65\156\164\55\143\x65\156\x74\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\141\144\145\x72\137\145\156\144", ["\x6e\157\x6e\145\137\141\155\x70" => __("\x4e\157\x6e\x65\40\101\115\x50\40\x56\x65\x72\x73\151\x6f\x6e", PR__CVR__PMPR)]); } }
