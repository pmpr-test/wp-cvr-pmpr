<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebec7b4f6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\x70\137\156\141\x76", [$this, "\x6e\x6b\x79\143\x73\167\x65\x69\141\x67\147\x75\143\163\x75\161"])->waqewsckuayqguos("\x61\x6d\x70\137\x68\x65\x61\x64\145\162\137\145\x6e\144", [$this, "\x73\x77\x6f\x71\155\147\x61\163\171\157\x67\161\165\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\x6e\144\x65\162\137\x6c\157\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\x74\x61\151\x6e\145\x72\x5f\x63\x6c\141\163\x73" => "\x64\55\x66\x6c\x65\170\40\x6a\x75\x73\x74\x69\x66\171\55\x63\157\156\164\x65\x6e\x74\x2d\143\145\x6e\x74\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\141\x64\145\x72\137\145\x6e\144", ["\156\157\156\145\137\x61\x6d\160" => __("\x4e\x6f\156\x65\40\x41\x4d\120\x20\x56\145\162\163\x69\157\x6e", PR__CVR__PMPR)]); } }
