<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520e51b858             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\160\137\x6e\141\x76", [$this, "\x6e\x6b\171\143\163\x77\145\151\x61\x67\147\165\143\x73\x75\161"])->waqewsckuayqguos("\141\x6d\x70\137\150\x65\141\144\x65\x72\x5f\145\x6e\144", [$this, "\x73\167\x6f\161\155\x67\x61\x73\171\157\147\x71\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\156\x64\145\162\137\154\157\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\156\x74\141\x69\156\145\x72\x5f\143\154\141\163\163" => "\x64\x2d\146\x6c\145\x78\x20\152\x75\163\x74\x69\x66\171\55\143\157\x6e\x74\145\x6e\x74\x2d\x63\x65\156\164\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\141\x64\x65\x72\x5f\145\x6e\x64", ["\x6e\x6f\156\x65\137\141\155\160" => __("\116\157\156\145\40\x41\115\x50\40\x56\x65\162\x73\151\x6f\156", PR__CVR__PMPR)]); } }
