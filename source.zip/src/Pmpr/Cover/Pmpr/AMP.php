<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e8485ec20             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\x70\137\x6e\141\x76", [$this, "\156\153\x79\x63\163\167\x65\151\141\147\x67\165\x63\163\165\x71"])->waqewsckuayqguos("\x61\x6d\160\x5f\150\145\141\144\145\x72\137\145\156\x64", [$this, "\163\x77\x6f\161\x6d\x67\141\x73\171\x6f\147\161\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\144\145\162\137\154\157\147\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\x74\141\151\156\145\162\137\143\x6c\141\163\163" => "\144\55\x66\154\x65\x78\x20\152\x75\163\164\151\146\x79\55\x63\x6f\156\x74\145\x6e\164\x2d\143\145\156\x74\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\x61\x64\x65\162\x5f\x65\156\144", ["\156\157\156\145\137\x61\x6d\x70" => __("\x4e\157\156\x65\40\x41\x4d\x50\40\x56\x65\x72\x73\151\157\x6e", PR__CVR__PMPR)]); } }
