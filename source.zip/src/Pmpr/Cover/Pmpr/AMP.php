<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c037a3c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\160\x5f\x6e\141\x76", [$this, "\x6e\153\x79\x63\x73\167\145\x69\141\x67\x67\165\143\163\165\x71"])->waqewsckuayqguos("\141\155\x70\137\150\145\x61\144\x65\x72\137\x65\156\144", [$this, "\163\x77\x6f\x71\155\147\141\x73\171\157\x67\161\165\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\144\145\x72\137\x6c\157\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\x6f\x6e\164\x61\x69\x6e\145\162\137\143\154\141\x73\163" => "\x64\55\x66\x6c\x65\170\x20\152\165\163\164\x69\146\x79\x2d\x63\157\x6e\x74\x65\x6e\x74\x2d\x63\x65\x6e\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\x64\145\162\x5f\x65\156\x64", ["\x6e\157\x6e\x65\137\141\155\x70" => __("\116\157\x6e\x65\40\101\x4d\120\40\x56\145\x72\163\x69\x6f\x6e", PR__CVR__PMPR)]); } }
