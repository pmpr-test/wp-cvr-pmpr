<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e16e2f881             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Cover\Pmpr\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
