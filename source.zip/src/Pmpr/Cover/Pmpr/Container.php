<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e59ebda0ac3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Cover\Pmpr\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
