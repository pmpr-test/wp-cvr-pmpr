<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f86533e5c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('render_footer', [$this, 'render'])->qcsmikeggeemccuu('wp_footer', [$this, 'ygkcekqkeiyeysqi']); } public function render() { echo $this->iuygowkemiiwqmiw('footer'); } public function ygkcekqkeiyeysqi() { if ($this->wkiaeewoqmsougim(Customizer::kuggasqqyiceoeqi)) { $swqimwqeweekeusq = $this->caokeucsksukesyo()->wgqqgewcmcemoewo(); $wkaqekwwgqsqwcoi = $this->wkiaeewoqmsougim(Customizer::yewwoieoeaeosiwg, IconInterface::kwiakuikccqseiku); $wkaqekwwgqsqwcoi = $swqimwqeweekeusq->cuoygaaeqeqcuggu($wkaqekwwgqsqwcoi, ['class' => 'icon-lg icon-dark'], [Constants::kicoscymgmgqeqgy => true]); echo $swqimwqeweekeusq->yuawgssgauywkiia($wkaqekwwgqsqwcoi, '#top', ['rel' => 'nofollow', 'id' => 'back-to-top', 'class' => 'btn btn-sm shadow btn-gray-200 scroll-to position-fixed bottom-0 left-0 m-3 m-md-5 d-none p-1']); } } }
