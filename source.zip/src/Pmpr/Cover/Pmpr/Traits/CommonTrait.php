<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef509c6b563             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [Constants::qisqmmesuewemeqg => ["\143\162\x6f\x70" => 1, "\x77\x69\x64\x74\150" => 803, "\150\x65\151\147\x68\x74" => 450, "\143\165\163\164\157\x6d" => 0], Constants::MEDIUM => ["\143\x72\157\x70" => 1, "\167\151\x64\164\150" => 200, "\x68\x65\x69\147\150\x74" => 200, "\x63\x75\x73\x74\x6f\155" => 0], Constants::egwoacukmsioosum => ["\x63\162\157\x70" => 1, "\x77\x69\144\x74\150" => 120, "\150\145\151\x67\150\x74" => 100, "\143\165\x73\164\157\155" => 0], Constants::meugkwqwuyoyeeqs => ["\x63\x72\x6f\x70" => 1, "\167\151\144\164\150" => 80, "\150\145\x69\x67\x68\164" => 80, "\143\165\x73\164\157\155" => 1]]; } }
