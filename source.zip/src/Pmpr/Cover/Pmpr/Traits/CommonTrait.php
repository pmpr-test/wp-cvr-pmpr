<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebec7b4f6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [Constants::qisqmmesuewemeqg => ["\x63\x72\157\160" => 1, "\x77\151\144\164\150" => 803, "\150\x65\x69\x67\x68\x74" => 450, "\x63\165\x73\x74\157\x6d" => 0], Constants::MEDIUM => ["\x63\162\157\x70" => 1, "\167\x69\x64\164\x68" => 200, "\150\x65\151\x67\150\x74" => 200, "\143\165\163\164\157\155" => 0], Constants::egwoacukmsioosum => ["\x63\162\157\x70" => 1, "\167\x69\144\164\x68" => 120, "\150\145\151\147\x68\164" => 100, "\143\165\163\164\x6f\155" => 0], Constants::meugkwqwuyoyeeqs => ["\x63\x72\x6f\x70" => 1, "\x77\x69\x64\164\150" => 80, "\x68\x65\x69\x67\150\x74" => 80, "\143\165\163\164\157\155" => 1]]; } }
