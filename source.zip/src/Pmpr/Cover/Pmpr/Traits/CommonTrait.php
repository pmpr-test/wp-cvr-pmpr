<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705174dabba2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [Constants::qisqmmesuewemeqg => ["\x63\x72\x6f\x70" => 1, "\x77\151\144\164\x68" => 803, "\x68\x65\151\147\x68\164" => 450, "\x63\x75\x73\x74\157\x6d" => 0], Constants::MEDIUM => ["\x63\x72\x6f\160" => 1, "\167\x69\x64\x74\x68" => 200, "\150\x65\x69\x67\x68\164" => 200, "\x63\x75\x73\x74\157\155" => 0], Constants::egwoacukmsioosum => ["\143\x72\x6f\160" => 1, "\x77\151\x64\x74\150" => 120, "\x68\145\x69\x67\x68\164" => 100, "\x63\x75\x73\x74\157\155" => 0], Constants::meugkwqwuyoyeeqs => ["\x63\162\157\160" => 1, "\167\x69\x64\164\x68" => 80, "\x68\145\151\147\x68\x74" => 80, "\143\x75\x73\164\157\x6d" => 1]]; } }
