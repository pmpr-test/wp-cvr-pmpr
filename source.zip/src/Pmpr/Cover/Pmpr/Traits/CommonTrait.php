<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e597bf4c4c9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [Constants::qisqmmesuewemeqg => ['crop' => 1, 'width' => 803, 'height' => 450, 'custom' => 0], Constants::MEDIUM => ['crop' => 1, 'width' => 200, 'height' => 200, 'custom' => 0], Constants::egwoacukmsioosum => ['crop' => 1, 'width' => 120, 'height' => 100, 'custom' => 0], Constants::meugkwqwuyoyeeqs => ['crop' => 1, 'width' => 80, 'height' => 80, 'custom' => 1]]; } }
