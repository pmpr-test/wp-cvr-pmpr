<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520e51b858             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\x64\151\166")->oiikmkeaimmqgaiu("\144\151\166")->seqmucuwuueuqekq(["\143\x6c\141\163\163" => "\x72\x6f\x77\40\155\164\55\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\x6c\141\x73\x73", "\x62\164\x6e\x20\142\x74\156\x2d\163\x6d\40\x62\164\x6e\55\147\x72\x61\171\x2d\65\x30\x30\40\142\164\156\55\x62\x6c\x6f\x63\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\x61\x73\163", "\143\157\x6c\55\x36"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
