<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c6f94e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\x64\x69\x76")->oiikmkeaimmqgaiu("\144\151\x76")->seqmucuwuueuqekq(["\x63\x6c\141\163\163" => "\x72\157\167\40\155\164\x2d\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\x6c\x61\x73\163", "\142\x74\x6e\x20\x62\x74\x6e\x2d\163\x6d\40\142\164\156\55\147\x72\141\x79\x2d\x35\x30\x30\40\142\164\x6e\x2d\x62\x6c\x6f\143\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\x61\x73\163", "\143\x6f\154\x2d\x36"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
