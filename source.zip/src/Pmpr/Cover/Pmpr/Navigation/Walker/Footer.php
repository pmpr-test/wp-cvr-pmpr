<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fd752f11             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\144\151\166")->oiikmkeaimmqgaiu("\x64\151\x76")->seqmucuwuueuqekq(["\x63\x6c\x61\163\x73" => "\162\157\x77\40\x6d\x74\x2d\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\x6c\x61\163\163", "\142\x74\x6e\x20\x62\x74\x6e\x2d\x73\x6d\x20\x62\164\156\x2d\x67\162\141\x79\x2d\65\60\60\x20\142\164\x6e\55\x62\154\x6f\x63\153"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\x6c\141\x73\163", "\143\x6f\x6c\55\x36"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
