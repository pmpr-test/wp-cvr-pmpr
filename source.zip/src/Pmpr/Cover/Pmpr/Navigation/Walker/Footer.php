<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8614636e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\x64\x69\166")->oiikmkeaimmqgaiu("\x64\151\166")->seqmucuwuueuqekq(["\x63\154\x61\163\x73" => "\x72\x6f\167\x20\155\164\55\x34"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\154\141\x73\163", "\142\164\x6e\40\142\164\x6e\55\163\155\x20\142\164\x6e\55\147\x72\141\171\x2d\x35\60\60\40\142\164\x6e\55\x62\154\157\x63\153"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\x61\163\163", "\x63\x6f\x6c\55\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
