<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebec7b4f6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\144\151\166")->oiikmkeaimmqgaiu("\144\151\x76")->seqmucuwuueuqekq(["\143\154\x61\x73\163" => "\162\x6f\167\x20\155\164\x2d\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\x61\163\x73", "\x62\x74\x6e\x20\x62\164\x6e\x2d\x73\x6d\40\142\164\156\55\x67\162\x61\x79\55\x35\60\x30\x20\x62\x74\x6e\55\142\x6c\157\x63\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\141\x73\x73", "\143\157\154\55\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
