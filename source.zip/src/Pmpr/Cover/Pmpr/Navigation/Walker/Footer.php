<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77b8552a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\144\x69\x76")->oiikmkeaimmqgaiu("\x64\151\x76")->seqmucuwuueuqekq(["\143\x6c\141\163\163" => "\162\x6f\x77\40\155\x74\55\x34"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\x61\x73\163", "\x62\164\156\x20\x62\164\x6e\55\163\x6d\40\142\x74\156\55\x67\x72\141\x79\55\65\x30\x30\x20\x62\164\156\55\x62\154\157\x63\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\141\x73\x73", "\x63\x6f\x6c\x2d\x36"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
