<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fd752f11             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\164")->gswweykyogmsyawy(__("\x4f\160\164\x69\155\151\x7a\x61\164\x69\x6f\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\x73\x5f\150\x65\141\144\145\162", [$this, "\x63\x77\171\143\141\x77\x63\x79\x67\x6b\x69\141\x65\x65\x67\151"])->aqaqisyssqeomwom("\150\x61\x73\137\x66\157\x6f\x74\145\162", [$this, "\x63\x77\x79\143\141\167\143\171\x67\x6b\x69\x61\x65\145\x67\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
