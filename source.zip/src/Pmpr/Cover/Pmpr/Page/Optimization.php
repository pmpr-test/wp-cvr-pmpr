<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77b8552a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\137\x68\x65\x61\144\145\162", [$this, "\x63\167\x79\143\141\167\143\x79\x67\153\151\141\x65\145\x67\151"])->aqaqisyssqeomwom("\x68\x61\x73\x5f\146\157\x6f\x74\145\x72", [$this, "\x63\x77\x79\x63\x61\167\143\x79\x67\x6b\151\141\145\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\164\x69\155\151\x7a\141\x74\x69\157\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto eqkauqciwewmgeoi; } $umuecysoywoumgwo = false; eqkauqciwewmgeoi: return $umuecysoywoumgwo; } }
