<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758160b4bf7f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\164")->gswweykyogmsyawy(__("\117\160\x74\151\x6d\151\x7a\141\x74\x69\157\156", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\141\x73\x5f\150\145\x61\x64\x65\162", [$this, "\x63\167\171\143\x61\x77\143\x79\x67\x6b\151\x61\x65\145\x67\x69"])->aqaqisyssqeomwom("\x68\x61\x73\137\x66\x6f\x6f\164\145\162", [$this, "\x63\167\x79\143\141\167\x63\x79\x67\153\151\x61\x65\x65\147\x69"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
