<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0002d08db             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\164")->gswweykyogmsyawy(__("\x4f\160\x74\151\155\x69\172\x61\x74\x69\x6f\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\x5f\150\x65\x61\x64\x65\x72", [$this, "\143\167\171\x63\x61\x77\143\171\147\153\151\141\x65\x65\x67\x69"])->aqaqisyssqeomwom("\x68\141\163\137\146\x6f\x6f\x74\x65\162", [$this, "\143\x77\171\x63\141\167\x63\x79\147\x6b\x69\141\145\x65\147\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
