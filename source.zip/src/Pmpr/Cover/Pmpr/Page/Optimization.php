<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e16e2f881             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\164")->gswweykyogmsyawy(__("\117\x70\164\x69\155\x69\x7a\141\164\x69\x6f\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\163\x5f\150\x65\x61\x64\145\162", [$this, "\143\x77\171\143\x61\x77\x63\171\x67\153\x69\x61\145\145\147\151"])->aqaqisyssqeomwom("\x68\141\163\137\x66\157\x6f\x74\145\x72", [$this, "\143\167\x79\143\x61\167\x63\171\147\x6b\x69\x61\145\145\147\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
