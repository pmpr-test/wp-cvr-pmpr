<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef509c6b563             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\x73\137\x68\145\x61\x64\145\x72", [$this, "\143\x77\171\x63\141\167\143\171\x67\x6b\151\141\145\x65\x67\x69"])->aqaqisyssqeomwom("\150\x61\163\137\x66\157\x6f\x74\x65\162", [$this, "\143\167\x79\x63\141\x77\x63\x79\147\x6b\151\x61\x65\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\x74\x69\155\x69\x7a\141\164\x69\x6f\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto wcesymwqykqoyuqk; } $umuecysoywoumgwo = false; wcesymwqykqoyuqk: return $umuecysoywoumgwo; } }
