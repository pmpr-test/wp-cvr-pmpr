<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520e51b858             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\164")->gswweykyogmsyawy(__("\117\160\164\151\x6d\x69\172\141\x74\151\157\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\x5f\150\x65\141\x64\x65\162", [$this, "\x63\x77\171\143\x61\167\x63\x79\x67\x6b\x69\x61\x65\145\147\151"])->aqaqisyssqeomwom("\150\x61\x73\137\146\157\157\x74\x65\x72", [$this, "\x63\x77\x79\x63\x61\x77\143\x79\147\x6b\151\141\145\145\147\x69"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto wcesymwqykqoyuqk; } $umuecysoywoumgwo = false; wcesymwqykqoyuqk: return $umuecysoywoumgwo; } }
