<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b5df5a2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\164")->gswweykyogmsyawy(__("\x4f\x70\164\151\x6d\x69\x7a\141\x74\151\x6f\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\137\x68\145\141\x64\x65\162", [$this, "\143\167\171\143\141\167\x63\x79\x67\x6b\151\141\145\x65\x67\151"])->aqaqisyssqeomwom("\150\x61\163\137\146\157\157\x74\x65\162", [$this, "\143\x77\x79\143\x61\x77\143\x79\147\x6b\x69\141\145\x65\x67\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
