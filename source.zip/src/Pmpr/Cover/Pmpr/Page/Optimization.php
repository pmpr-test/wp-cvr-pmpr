<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebec7b4f6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\x5f\x68\x65\141\x64\x65\x72", [$this, "\x63\x77\171\x63\x61\167\143\171\147\153\151\x61\145\x65\x67\x69"])->aqaqisyssqeomwom("\x68\141\x73\137\146\x6f\x6f\x74\145\162", [$this, "\143\x77\x79\x63\x61\167\x63\x79\x67\x6b\151\x61\x65\x65\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\164\151\x6d\x69\172\x61\x74\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto eqkauqciwewmgeoi; } $umuecysoywoumgwo = false; eqkauqciwewmgeoi: return $umuecysoywoumgwo; } }
