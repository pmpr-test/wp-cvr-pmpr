<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c6f94e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\164")->gswweykyogmsyawy(__("\x4f\160\164\151\155\151\x7a\141\x74\151\x6f\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\x5f\x68\x65\x61\x64\x65\x72", [$this, "\143\167\171\143\141\167\x63\171\147\x6b\151\141\145\x65\147\151"])->aqaqisyssqeomwom("\150\141\x73\x5f\146\x6f\157\x74\145\162", [$this, "\143\x77\x79\x63\x61\x77\143\x79\147\153\x69\141\x65\x65\147\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
