<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e8485ec20             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\x74")->gswweykyogmsyawy(__("\x4f\x70\164\x69\x6d\x69\172\141\x74\x69\x6f\156", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\163\137\x68\x65\x61\x64\145\162", [$this, "\143\x77\171\x63\141\167\143\171\x67\153\x69\x61\x65\x65\x67\x69"])->aqaqisyssqeomwom("\150\x61\163\x5f\x66\157\157\x74\145\x72", [$this, "\143\x77\171\x63\x61\x77\x63\171\x67\x6b\151\141\x65\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
