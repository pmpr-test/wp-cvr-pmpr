<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675815f2d6947             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\164")->gswweykyogmsyawy(__("\117\160\x74\x69\x6d\x69\172\141\x74\151\x6f\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\141\163\137\x68\x65\141\x64\145\x72", [$this, "\143\x77\171\x63\141\167\x63\x79\147\x6b\x69\141\x65\145\147\x69"])->aqaqisyssqeomwom("\150\141\163\x5f\146\157\x6f\x74\x65\162", [$this, "\x63\x77\171\x63\141\x77\x63\171\147\153\151\x61\x65\145\x67\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
