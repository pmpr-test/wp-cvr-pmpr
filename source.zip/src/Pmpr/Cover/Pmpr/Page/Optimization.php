<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705174dabba2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\164")->gswweykyogmsyawy(__("\x4f\160\164\151\x6d\151\x7a\x61\164\x69\157\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\x5f\150\145\141\x64\145\162", [$this, "\x63\167\171\x63\x61\x77\143\x79\x67\x6b\x69\141\145\145\147\151"])->aqaqisyssqeomwom("\x68\x61\x73\x5f\146\157\157\x74\145\x72", [$this, "\x63\x77\171\143\141\x77\143\171\x67\x6b\x69\141\145\145\147\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto wcesymwqykqoyuqk; } $umuecysoywoumgwo = false; wcesymwqykqoyuqk: return $umuecysoywoumgwo; } }
