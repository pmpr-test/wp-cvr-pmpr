<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0678d0ad             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->gswweykyogmsyawy(__("\117\x70\164\x69\x6d\151\x7a\x61\164\x69\x6f\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\x73\x5f\150\x65\x61\144\145\162", [$this, "\x63\167\x79\x63\141\167\143\171\x67\153\x69\x61\x65\x65\x67\x69"])->aqaqisyssqeomwom("\x68\141\x73\137\146\x6f\157\164\x65\x72", [$this, "\143\167\x79\143\141\x77\x63\171\x67\x6b\x69\x61\x65\145\147\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
