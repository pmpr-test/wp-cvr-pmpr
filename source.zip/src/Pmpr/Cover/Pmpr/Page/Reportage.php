<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c037a3c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Reportage extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x72\145\160\x6f\162\x74\x61\147\145")->gswweykyogmsyawy(__("\122\x65\160\157\x72\x74\141\147\x65", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::akmweacgkkukkakq)); } }
