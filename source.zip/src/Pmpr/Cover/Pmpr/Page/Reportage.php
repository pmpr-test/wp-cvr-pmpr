<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8614636e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Reportage extends Common { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x72\x65\x70\x6f\162\x74\x61\x67\145")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::akmweacgkkukkakq)); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x52\x65\160\157\x72\x74\x61\x67\145", PR__CVR__PMPR)); } }
