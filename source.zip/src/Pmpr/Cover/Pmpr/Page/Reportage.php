<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d369e9de             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Reportage extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw('reportage')->gswweykyogmsyawy(__('Reportage', PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::akmweacgkkukkakq)); parent::qiccuiwooiquycsg(); } }
