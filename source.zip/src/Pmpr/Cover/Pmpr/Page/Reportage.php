<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675815f2d6947             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Reportage extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\162\145\160\157\x72\x74\x61\147\145")->gswweykyogmsyawy(__("\x52\145\160\157\162\x74\x61\x67\145", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::akmweacgkkukkakq)); } }
