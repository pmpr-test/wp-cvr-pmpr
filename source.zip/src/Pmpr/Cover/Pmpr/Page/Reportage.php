<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e16e2f881             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Reportage extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x72\145\x70\x6f\162\164\141\147\145")->gswweykyogmsyawy(__("\x52\x65\x70\x6f\x72\164\141\147\x65", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::akmweacgkkukkakq)); } }
