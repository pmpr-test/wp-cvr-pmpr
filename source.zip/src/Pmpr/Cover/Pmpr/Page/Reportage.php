<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef509c6b563             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Reportage extends Common { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\162\x65\160\x6f\x72\164\141\147\x65")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::akmweacgkkukkakq)); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\122\145\x70\157\x72\164\141\x67\x65", PR__CVR__PMPR)); } }
