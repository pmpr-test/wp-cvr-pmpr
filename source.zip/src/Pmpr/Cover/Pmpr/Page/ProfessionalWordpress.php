<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0002d08db             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\x72\157\146\145\x73\x73\x69\x6f\x6e\x61\x6c\x2d\x77\157\162\144\160\162\x65\x73\163")->gswweykyogmsyawy(__("\120\x72\157\146\145\163\163\x69\157\x6e\141\x6c\40\x57\x6f\x72\144\160\x72\x65\163\x73", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
