<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b5df5a2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\x72\157\146\x65\163\163\151\157\156\x61\x6c\x2d\167\157\162\144\160\x72\145\163\x73")->gswweykyogmsyawy(__("\x50\x72\157\146\x65\163\x73\151\x6f\156\141\x6c\x20\x57\x6f\x72\x64\160\x72\x65\x73\x73", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
