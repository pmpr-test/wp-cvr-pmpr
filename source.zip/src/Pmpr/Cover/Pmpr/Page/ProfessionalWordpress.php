<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0678d0ad             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\162\x6f\146\145\163\163\x69\157\x6e\141\154\55\167\157\162\144\x70\162\x65\163\x73")->gswweykyogmsyawy(__("\x50\162\x6f\146\145\163\x73\x69\157\x6e\141\x6c\x20\x57\157\162\144\160\162\x65\x73\163", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
