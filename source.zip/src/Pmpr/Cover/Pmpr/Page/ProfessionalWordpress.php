<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c037a3c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\162\157\x66\x65\163\x73\x69\157\x6e\141\x6c\x2d\167\x6f\162\x64\x70\162\x65\x73\x73")->gswweykyogmsyawy(__("\x50\x72\157\146\145\x73\163\151\x6f\x6e\x61\x6c\x20\127\x6f\x72\x64\160\162\x65\163\163", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
