<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46a91a961             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\162\x6f\x66\145\x73\x73\151\157\x6e\x61\154\55\167\x6f\x72\144\x70\162\x65\x73\163")->gswweykyogmsyawy(__("\x50\x72\x6f\x66\x65\163\163\151\157\156\x61\x6c\40\x57\x6f\x72\144\160\x72\x65\163\163", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
