<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520e51b858             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\162\x6f\146\145\x73\163\x69\157\156\141\x6c\x2d\x77\x6f\162\x64\x70\x72\145\163\163")->gswweykyogmsyawy(__("\x50\x72\x6f\146\145\163\x73\x69\157\156\x61\x6c\40\127\x6f\162\144\160\x72\145\x73\163", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
