<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758160b4bf7f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\162\x6f\146\145\x73\163\151\157\x6e\141\154\55\x77\x6f\162\144\x70\x72\x65\x73\163")->gswweykyogmsyawy(__("\x50\162\157\146\145\x73\163\x69\x6f\156\x61\x6c\40\x57\x6f\x72\x64\160\x72\145\163\x73", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
