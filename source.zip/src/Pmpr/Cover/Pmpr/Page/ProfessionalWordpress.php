<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77b8552a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\162\x6f\x66\x65\163\163\x69\x6f\156\x61\154\x2d\x77\x6f\x72\144\x70\162\x65\x73\x73")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\120\162\x6f\146\x65\x73\163\x69\x6f\x6e\141\x6c\x20\127\x6f\162\144\x70\162\x65\163\163", PR__CVR__PMPR)); } }
