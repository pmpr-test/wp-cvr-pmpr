<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebec7b4f6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\x72\x6f\x66\x65\x73\x73\151\157\x6e\141\x6c\x2d\x77\157\x72\144\160\162\145\x73\163")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\120\162\x6f\146\145\163\163\151\157\x6e\141\154\40\127\157\162\x64\160\x72\x65\x73\x73", PR__CVR__PMPR)); } }
