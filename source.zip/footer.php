<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dda3c233349             |
    |_______________________________________|
*/
 do_action('render_footer');
