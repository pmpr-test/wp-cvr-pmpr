<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e5803978c8f             |
    |_______________________________________|
*/
 do_action('render_footer');
