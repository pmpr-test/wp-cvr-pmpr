<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c424d8d838             |
    |_______________________________________|
*/
 do_action('render_footer');
