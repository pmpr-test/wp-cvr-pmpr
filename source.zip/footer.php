<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e59ebda0ac3             |
    |_______________________________________|
*/
 do_action('render_footer');
