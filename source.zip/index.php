<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705174dabba2             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\x69\164\x5f\x63\157\x76\x65\x72");
