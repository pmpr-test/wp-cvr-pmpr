<?php

defined( 'ABSPATH' ) || exit;

?>
<header class="mt-5 mb-2">
    <div class="h2 text-primary"><?php the_title() ?></div>
</header>

